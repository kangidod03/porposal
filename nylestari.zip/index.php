<!DOCTYPE html>
<html lang="id">

<head>
    
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());

      gtag('config', 'G-L2XL4CEVBD');
    </script>
    <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-3541147626555936"
      crossorigin="anonymous"></script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Primary Meta Tags -->
    <title>Sambal Pecel Ny Lestari - Bumbu Pecel Khas Kediri Otentik</title>
    <meta name="title" content="Sambal Pecel Ny Lestari - Bumbu Pecel Khas Kediri Otentik">
    <meta name="description" content="Jual Sambal Pecel Ny Lestari khas Kediri asli warisan resep Jawa Timur. Terbuat dari bahan alami tanpa pengawet, gurih, pedas, dan higienis. Pesan online sekarang!">
    <meta name="keywords" content="sambal pecel, bumbu pecel kediri, sambal pecel ny lestari, bumbu pecel asli kediri, sambal pecel enak, oleh oleh khas kediri, sambal kacang">
    <meta name="robots" content="index, follow">
    <meta name="language" content="Indonesian">
    <meta name="author" content="Ny Lestari">
    <link rel="canonical" href="https://nylestari.com/">

    <!-- Favicon -->
    <link rel="icon" type="image/jpeg" href="logo-lestari.jpg">
    <link rel="apple-touch-icon" href="logo-lestari.jpg">

    <!-- Open Graph / Facebook / WhatsApp -->
    <meta property="og:type" content="website">
    <meta property="og:url" content="https://nylestari.com/">
    <meta property="og:title" content="Sambal Pecel Ny Lestari - Bumbu Pecel Khas Kediri Otentik">
    <meta property="og:description" content="Sensasi kelezatan bumbu kacang resep otentik warisan Kediri. Gurih, pedas, higienis, dan tanpa bahan pengawet!">
    <meta property="og:image" content="https://nylestari.com/pedassedang.jpg">

    <!-- Twitter -->
    <meta property="twitter:card" content="summary_large_image">
    <meta property="twitter:url" content="https://nylestari.com/">
    <meta property="twitter:title" content="Sambal Pecel Ny Lestari - Bumbu Pecel Khas Kediri Otentik">
    <meta property="twitter:description" content="Sensasi kelezatan bumbu kacang resep otentik warisan Kediri. Gurih, pedas, higienis, dan tanpa bahan pengawet!">
    <meta property="twitter:image" content="https://nylestari.com/pedassedang.jpg">

    <!-- Fonts & Icons -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&family=Playfair+Display:wght@700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <!-- Structured Data (Schema.org JSON-LD) -->
    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "LocalBusiness",
      "name": "Sambal Pecel Ny Lestari",
      "image": "https://nylestari.com/logo-lestari.jpg",
      "url": "https://nylestari.com/",
      "telephone": "+6282220468952",
      "priceRange": "Rp 35.000 - Rp 120.000",
      "address": {
        "@type": "PostalAddress",
        "addressLocality": "Kediri",
        "addressRegion": "Jawa Timur",
        "addressCountry": "ID"
      },
      "description": "Produsen dan toko resmi Sambal Pecel Ny Lestari khas Kota Kediri. Menyediakan bumbu pecel kacang pedas sedang, extra pedas, dan paket hemat."
    }
    </script>

    <script type="application/ld+json">
    {
      "@context": "https://schema.org/",
      "@type": "ItemList",
      "itemListElement": [
        {
          "@type": "ListItem",
          "position": 1,
          "item": {
            "@type": "Product",
            "name": "Sambal Pecel Ny Lestari - Pedas Sedang 250gr",
            "image": "https://nylestari.com/pedassedang.jpg",
            "description": "Sambal pecel rasa gurih kacang dengan tingkat kepedasan sedang khas Kediri.",
            "offers": {
              "@type": "Offer",
              "priceCurrency": "IDR",
              "price": "45000",
              "availability": "https://schema.org/InStock"
            }
          }
        },
        {
          "@type": "ListItem",
          "position": 2,
          "item": {
            "@type": "Product",
            "name": "Sambal Pecel Ny Lestari - Extra Pedas 250gr",
            "image": "https://nylestari.com/exreapedas.jpg",
            "description": "Sambal pecel ekstra pedas menggunakan cabai rawit pilihan khas Kediri.",
            "offers": {
              "@type": "Offer",
              "priceCurrency": "IDR",
              "price": "45000",
              "availability": "https://schema.org/InStock"
            }
          }
        },
        {
          "@type": "ListItem",
          "position": 3,
          "item": {
            "@type": "Product",
            "name": "Sambal Pecel Ny Lestari - Paket Hemat 1kg",
            "image": "https://nylestari.com/pakethemat.jpg",
            "description": "Paket hemat bumbu pecel Kediri 1 kg cocok untuk kebutuhan keluarga atau oleh-oleh.",
            "offers": {
              "@type": "Offer",
              "priceCurrency": "IDR",
              "price": "110000",
              "availability": "https://schema.org/InStock"
            }
          }
        }
      ]
    }
    </script>

    <style>
        :root {
            --primary-color: #C0392B;
            --secondary-color: #E67E22;
            --dark-color: #2C3E50;
            --light-color: #FDFEFE;
            --accent-color: #27AE60;
            --nu-green: #578b40;
            --footer-text-white: #FFFFFF; 
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            color: #333;
            background-color: #FAFAFA;
            line-height: 1.6;
        }

        header {
            background-color: var(--light-color);
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            position: fixed;
            width: 100%;
            top: 0;
            z-index: 1000;
        }

        /* Efek Embos Website Dijual */
.banner-dijual {
    background: linear-gradient(135deg, #d35400, #c0392b);
    color: #ffffff;
    text-align: center;
    padding: 15px 20px;
    font-family: 'Playfair Display', serif;
    font-size: 28px;
    font-weight: 700;
    letter-spacing: 2px;
    
    box-shadow: inset 0 2px 4px rgba(255, 255, 255, 0.4), 
                0 4px 6px rgba(0, 0, 0, 0.2);
    text-shadow: 1px 1px 0px #78281f, 
                 -1px -1px 0px #f5b041, 
                 0px 3px 5px rgba(0, 0, 0, 0.5);
    border-bottom: 2px solid #900c3f;
    position: relative;
    z-index: 999;
}

@media (max-width: 768px) {
    .banner-dijual {
        font-size: 20px;
        padding: 12px 15px;
    }
}

        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            max-width: 1200px;
            margin: 0 auto;
            padding: 10px 20px;
        }

        .logo-container {
            display: flex;
            align-items: center;
            gap: 16px;
            text-decoration: none;
        }

        .logo-img {
            height: 90px;
            width: 90px;
            border-radius: 50%;
            object-fit: cover;
        }

        .logo-text {
            font-family: 'Playfair Display', serif;
            font-size: 48px;
            font-weight: 700;
            color: var(--primary-color);
        }

        .nav-links {
            display: flex;
            list-style: none;
            gap: 25px;
            align-items: center;
        }

        .nav-links a {
            text-decoration: none;
            color: var(--dark-color);
            font-weight: 500;
            transition: color 0.3s;
        }

        .nav-links a:hover {
            color: var(--primary-color);
        }

        .btn-order {
            background-color: var(--primary-color);
            color: white !important;
            padding: 8px 20px;
            border-radius: 25px;
            font-weight: 600 !important;
            transition: background 0.3s;
        }

        .btn-order:hover {
            background-color: #A93226 !important;
        }

        /* Hero Section */
        .hero {
            margin-top: 110px;
            background: linear-gradient(rgba(0,0,0,0.6), rgba(0,0,0,0.6)), url('https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=1350&q=80');
            background-size: cover;
            background-position: center;
            height: 80vh;
            display: flex;
            align-items: center;
            text-align: center;
            color: white;
            padding: 0 20px;
        }

        .hero-content {
            max-width: 800px;
            margin: 0 auto;
        }

        .hero h1 {
            font-family: 'Playfair Display', serif;
            font-size: 48px;
            margin-bottom: 15px;
            color: #FFD700;
        }

        .hero p {
            font-size: 20px;
            margin-bottom: 30px;
        }

        .badge-pedas {
            display: inline-block;
            background-color: var(--primary-color);
            padding: 5px 15px;
            border-radius: 15px;
            font-size: 14px;
            font-weight: 600;
            margin-bottom: 20px;
            letter-spacing: 1px;
        }

        /* Keunggulan Section */
        .features {
            max-width: 1200px;
            margin: 80px auto;
            padding: 0 20px;
            text-align: center;
        }

        .section-title {
            font-family: 'Playfair Display', serif;
            font-size: 36px;
            color: var(--dark-color);
            margin-bottom: 50px;
            position: relative;
        }

        .section-title::after {
            content: '';
            width: 80px;
            height: 3px;
            background-color: var(--primary-color);
            position: absolute;
            bottom: -10px;
            left: 50%;
            transform: translateX(-50%);
        }

        .grid-3 {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 30px;
        }

        .feature-card {
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            transition: transform 0.3s;
        }

        .feature-card:hover {
            transform: translateY(-5px);
        }

        .feature-icon {
            font-size: 40px;
            color: var(--secondary-color);
            margin-bottom: 20px;
        }

        /* Produk Section */
        .products {
            background-color: #F4F6F6;
            padding: 80px 20px;
        }

        .product-card {
            background: white;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            text-align: left;
            display: flex;
            flex-direction: column;
        }

        .product-grid {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 30px;
            align-items: stretch;
        }

        .product-img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            display: block;
        }

        .product-info {
            padding: 20px;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            flex-grow: 1;
        }

        .product-price {
            font-size: 20px;
            font-weight: 700;
            color: var(--primary-color);
            margin: 10px 0 15px 0;
        }

        .btn-buy-product {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            background-color: var(--accent-color);
            color: white;
            padding: 10px 18px;
            border-radius: 20px;
            font-size: 15px;
            font-weight: 600;
            text-decoration: none;
            transition: background 0.3s;
            margin-top: auto;
        }

        .btn-buy-product:hover {
            background-color: #219653;
        }

        /* CTA Section */
        .cta-section {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            text-align: center;
            padding: 60px 20px;
        }

        .btn-whatsapp {
            display: inline-flex;
            align-items: center;
            gap: 10px;
            background-color: var(--accent-color);
            color: white;
            padding: 15px 35px;
            border-radius: 30px;
            font-size: 18px;
            font-weight: 600;
            text-decoration: none;
            margin-top: 25px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.2);
            transition: background 0.3s;
        }

        .btn-whatsapp:hover {
            background-color: #219653;
        }

        footer {
            background-color: var(--nu-green); /* Hijau Khas NU */
            color: var(--footer-text-white); /* Teks Putih */
            padding: 50px 20px 20px 20px;
            font-size: 15px;
        }

        .footer-container {
            max-width: 1200px;
            margin: 0 auto;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 40px;
            padding-bottom: 40px;
        }

        .footer-col h3 {
            font-family: 'Playfair Display', serif;
            font-size: 22px;
            font-weight: 700;
            letter-spacing: 1px;
            margin-bottom: 20px;
            text-transform: uppercase;
            color: var(--footer-text-white); /* Putih */
        }

        .footer-col p {
            line-height: 1.7;
            color: var(--footer-text-white); /* Putih */
            font-weight: 400;
        }

        .footer-contact-item {
            display: flex;
            align-items: flex-start;
            gap: 12px;
            margin-bottom: 15px;
            color: var(--footer-text-white); /* Putih */
            font-weight: 400;
        }

        .footer-contact-item i {
            font-size: 18px;
            margin-top: 3px;
            color: var(--footer-text-white); /* Putih */
        }

        .footer-socials {
            display: flex;
            gap: 15px;
        }

        .footer-socials a {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 42px;
            height: 42px;
            background-color: rgba(255, 255, 255, 0.15); /* Background transparan putih */
            color: var(--footer-text-white); /* Putih */
            border-radius: 8px;
            font-size: 20px;
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .footer-socials a:hover {
            background-color: #ffffff;
            color: var(--nu-green);
            transform: translateY(-3px);
        }

        .footer-bottom {
            max-width: 1200px;
            margin: 0 auto;
            border-top: 1px solid rgba(255, 255, 255, 0.2);
            padding-top: 25px;
            text-align: center;
            font-size: 14px;
            color: var(--footer-text-white); /* Putih */
            font-weight: 400;
        }

        @media (max-width: 992px) {
            .product-grid {
                grid-template-columns: repeat(2, minmax(0, 1fr));
            }
        }

        @media (max-width: 768px) {
            .hero h1 { font-size: 32px; }
            .hero p { font-size: 16px; }
            .nav-links { display: none; }
            .logo-img { height: 60px; width: 60px; }
            .logo-text { font-size: 30px; }
            .footer-container { text-align: left; }

            .product-grid {
                grid-template-columns: 1fr;
                gap: 22px;
            }

            .product-img {
                height: 240px;
            }
        }
    </style>
    
</head>

<body>


    <?php
        // Konfigurasi Nomor WhatsApp
        $nomor_wa = "6282220468952";

        // Template Pesan WhatsApp tiap Varian
        $wa_pedas_sedang = "https://wa.me/{$nomor_wa}?text=" . urlencode("Halo, saya ingin membeli Sambal Pecel Ny Lestari - Pedas Sedang (250gr).");
        $wa_extra_pedas  = "https://wa.me/{$nomor_wa}?text=" . urlencode("Halo, saya ingin membeli Sambal Pecel Ny Lestari - Extra Pedas (250gr).");
        $wa_paket_hemat  = "https://wa.me/{$nomor_wa}?text=" . urlencode("Halo, saya ingin membeli Sambal Pecel Ny Lestari - Paket Hemat (1 kg).");
        $wa_nasi_pecel   = "https://wa.me/{$nomor_wa}?text=" . urlencode("Halo, saya ingin memesan Nasi Kotak Pecel Ny Lestari - Rp 35.000.");
        $wa_peyek        = "https://wa.me/{$nomor_wa}?text=" . urlencode("Halo, saya ingin memesan Peyek Ny Lestari - Rp 120.000 per kaleng.");
        $wa_umum         = "https://wa.me/{$nomor_wa}?text=" . urlencode("Halo, saya ingin memesan Sambal Pecel Ny Lestari Khas Kediri.");
    ?>

    <!-- Header & Navigation -->
    <header>
        <div class="banner-dijual">
    ⚠️ WEBSITE INI DIJUAL ⚠️
</div>
        <nav class="navbar" aria-label="Navigasi Utama">
            <a href="https://nylestari.com/" class="logo-container">
                <img src="logo-lestari.jpg" alt="Logo Sambal Pecel Ny Lestari Kediri" class="logo-img" width="90" height="90">
                <span class="logo-text">Ny Lestari</span>
            </a>
            <ul class="nav-links">
                <li><a href="#home">Beranda</a></li>
                <li><a href="#tentang">Keunggulan</a></li>
                <li><a href="#produk">Produk</a></li>
                <li><a href="testimonial.php">Testimonial</a></li>
                <li><a href="berita.php">Berita Terbaru</a></li>

                <li><a href="<?php echo $wa_umum; ?>" target="_blank" rel="noopener noreferrer" class="btn-order"><i class="fab fa-whatsapp"></i> Beli Sekarang</a></li>
            </ul>
        </nav>
    </header>

    <main>

        <!-- Hero Section -->
        <section class="hero" id="home">

            <div class="hero-content">
                <span class="badge-pedas">🔥 PEDAS & NIKMAT</span>
                <h1>Ny Lestari - Sambal Pecel Khas Kota Kediri</h1>
                <p>Sensasi kelezatan bumbu kacang resep otentik warisan Jawa Timur. Dibuat dari bahan pilihan berkualitas tinggi untuk menyajikan cita rasa asli yang gurih, pedas, dan mantap!</p>
                <a href="<?php echo $wa_umum; ?>" target="_blank" rel="noopener noreferrer" class="btn-whatsapp"><i class="fab fa-whatsapp"></i> Pesan Sekarang</a>
            </div>
        </section>

        <!-- Keunggulan Section -->
        <section class="features" id="tentang">
            <h2 class="section-title">Mengapa Sambal Pecel Ny Lestari?</h2>
            <div class="grid-3">
                <div class="feature-card">
                    <div class="feature-icon"><i class="fas fa-pepper-hot"></i></div>
                    <h3>Pedas Otentik</h3>
                    <p>Menggunakan cabai pilihan segar berkualitas untuk rasa pedas mantap yang menggugah selera.</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon"><i class="fas fa-mortar-pestle"></i></div>
                    <h3>Resep Asli Kediri</h3>
                    <p>Diproses dengan bumbu rempah khas Kota Kediri, menciptakan aroma harum dan gurih yang pas.</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon"><i class="fas fa-shield-alt"></i></div>
                    <h3>Tanpa Pengawet</h3>
                    <p>Dibuat secara higienis tanpa bahan pengawet buatan, aman dan tahan lama untuk disimpan.</p>
                </div>
            </div>
        </section>

        <!-- Produk Section -->
        <section class="products" id="produk">
            <div style="max-width: 1200px; margin: 0 auto; text-align: center;">
                <h2 class="section-title">Pilihan Produk Ny Lestari</h2>
                <div class="product-grid">

                    <!-- Varian 1: Pedas Sedang -->
                    <article class="product-card">
                        <a href="<?php echo $wa_pedas_sedang; ?>" target="_blank" rel="noopener noreferrer">
                            <img src="pedassedang.jpg" alt="Sambal Pecel Ny Lestari Varian Pedas Sedang 250 gram" class="product-img" loading="lazy">
                        </a>
                        <div class="product-info">
                            <h3>Sambal Pecel - Pedas Sedang</h3>
                            <p>Cocok untuk Anda yang menyukai rasa gurih kacang dengan tingkat kepedasan yang pas.</p>
                            <div class="product-price">Rp 45.000 / 250gr</div>
                            <a href="<?php echo $wa_pedas_sedang; ?>" target="_blank" rel="noopener noreferrer" class="btn-buy-product">
                                <i class="fab fa-whatsapp"></i> Beli Pedas Sedang
                            </a>
                        </div>
                    </article>

                    <!-- Varian 2: Extra Pedas -->
                    <article class="product-card">
                        <a href="<?php echo $wa_extra_pedas; ?>" target="_blank" rel="noopener noreferrer">
                            <img src="exreapedas.jpg" alt="Sambal Pecel Ny Lestari Varian Extra Pedas 250 gram" class="product-img" loading="lazy">
                        </a>
                        <div class="product-info">
                            <h3>Sambal Pecel - Extra Pedas</h3>
                            <p>Dibuat khusus untuk pecinta pedas sejati dengan kepedasan cabai rawit pilihan.</p>
                            <div class="product-price">Rp 45.000 / 250gr</div>
                            <a href="<?php echo $wa_extra_pedas; ?>" target="_blank" rel="noopener noreferrer" class="btn-buy-product">
                                <i class="fab fa-whatsapp"></i> Beli Extra Pedas
                            </a>
                        </div>
                    </article>

                    <!-- Varian 3: Paket Hemat -->
                    <article class="product-card">
                        <a href="<?php echo $wa_paket_hemat; ?>" target="_blank" rel="noopener noreferrer">
                            <img src="pakethemat.jpg" alt="Sambal Pecel Ny Lestari Paket Hemat Kemasan 1 kg" class="product-img" loading="lazy">
                        </a>
                        <div class="product-info">
                            <h3>Paket Hemat (1 kg)</h3>
                            <p>Lebih hemat untuk kebutuhan keluarga atau oleh-oleh khas Kediri.</p>
                            <div class="product-price">Rp 110.000 / 1 kg</div>
                            <a href="<?php echo $wa_paket_hemat; ?>" target="_blank" rel="noopener noreferrer" class="btn-buy-product">
                                <i class="fab fa-whatsapp"></i> Beli Paket Hemat
                            </a>
                        </div>
                    </article>

                    <!-- Produk 4: Nasi Kotak Pecel -->
                    <article class="product-card">
                        <a href="<?php echo $wa_nasi_pecel; ?>" target="_blank" rel="noopener noreferrer">
                            <img src="pecel_kotak.jpg" alt="Nasi Kotak Pecel Ny Lestari" class="product-img" loading="lazy">
                        </a>
                        <div class="product-info">
                            <h3>Nasi Kotak Pecel</h3>
                            <p>Paket nasi kotak pecel lengkap, cocok untuk makan siang, acara, dan kebutuhan katering.</p>
                            <div class="product-price">Rp 35.000 / kotak</div>
                            <a href="<?php echo $wa_nasi_pecel; ?>" target="_blank" rel="noopener noreferrer" class="btn-buy-product">
                                <i class="fab fa-whatsapp"></i> Pesan Nasi Kotak
                            </a>
                        </div>
                    </article>

                    <!-- Produk 5: Peyek Kaleng -->
                    <article class="product-card">
                        <a href="<?php echo $wa_peyek; ?>" target="_blank" rel="noopener noreferrer">
                            <img src="peyeklengkap.jpg" alt="Peyek Ny Lestari kemasan kaleng" class="product-img" loading="lazy">
                        </a>
                        <div class="product-info">
                            <h3>Peyek Ny Lestari</h3>
                            <p>Aneka peyek renyah dan gurih dalam kemasan kaleng, cocok untuk camilan dan oleh-oleh.</p>
                            <div class="product-price">Rp 120.000 / kaleng</div>
                            <a href="<?php echo $wa_peyek; ?>" target="_blank" rel="noopener noreferrer" class="btn-buy-product">
                                <i class="fab fa-whatsapp"></i> Beli Peyek
                            </a>
                        </div>
                    </article>

                </div>
            </div>
        </section>

        <!-- CTA / Order Section -->
        <section class="cta-section" id="kontak">
            <h2>Siap Memanjakan Lidah Anda?</h2>
            <p style="margin-top: 10px;">Pesan Sambal Pecel "Ny Lestari" khas Kediri sekarang juga langsung via WhatsApp!</p>
            <a href="<?php echo $wa_umum; ?>" target="_blank" rel="noopener noreferrer" class="btn-whatsapp">
                <i class="fab fa-whatsapp" style="font-size: 24px;"></i> Hubungi via WhatsApp
            </a>
        </section>
    </main>

    <!-- FOOTER 3 KOLOM (HIJAU NU & TEKS PUTIH) -->
    <footer>
        <div class="footer-container">
            <!-- Kolom 1: Tentang -->
            <div class="footer-col">
                <h3>NY LESTARI</h3>
                <p>Kami adalah produsen Sambal Pecel khas Kediri yang didedikasikan untuk menyajikan kelezatan bumbu pecel berkualitas tinggi, dibuat dari bahan-bahan terbaik dan resep warisan otentik Jawa Timur.</p>
            </div>

            <!-- Kolom 2: Kontak -->
            <div class="footer-col">
                <h3>KONTAK</h3>
                <div class="footer-contact-item">
                    <i class="fas fa-map-marker-alt"></i>
                    <span>Jl Sawo, Desa Pelem - Kertosono, Jawa Timur, 64314</span>
                </div>
                <div class="footer-contact-item">
                    <i class="fas fa-phone-alt"></i>
                    <span>0822 2046 8952</span>
                </div>
            </div>

            <!-- Kolom 3: Sosial Media -->
            <div class="footer-col">
                <h3>IKUTI KAMI</h3>
                <div class="footer-socials">
                    <a href="https://www.instagram.com/nylestari_com/" target="_blank" aria-label="Instagram"><i class="fab fa-instagram"></i></a>
                    <a href="#" target="_blank" aria-label="TikTok"><i class="fab fa-tiktok"></i></a>
                </div>
            </div>
        </div>

        <!-- Copyright & Privacy Policy -->
        <!-- Copyright & Privacy Policy -->
    <div class="footer-bottom">
        <p>&copy; 2026 Copyright: <strong>Nylestari.com</strong> | <a href="javascript:void(0)" onclick="openPrivacyModal()" class="privacy-link">Kebijakan Privasi</a></p>
    </div>
</footer>

<!-- STRUKTUR MODAL POP-UP KEBIJAKAN PRIVASI -->
<div id="privacyModal" class="privacy-modal">
  <div class="privacy-modal-content">
    <span class="privacy-modal-close" onclick="closePrivacyModal()">&times;</span>
    
    <div class="privacy-body">
      <h1>KEBIJAKAN PRIVASI</h1>
      <p><strong>Terakhir diperbarui:</strong> 26 September 2026</p>
      
      <p>Selamat datang di Nylestari.com, website yang menyediakan informasi dan layanan terkait Sambel Pecel Nylestari, produk makanan, informasi produk, serta informasi lain yang berkaitan dengan usaha kami.</p>
      
      <p>Kami menghargai privasi setiap pengunjung website. Kebijakan Privasi ini menjelaskan bagaimana kami mengumpulkan, menggunakan, menyimpan, dan melindungi informasi yang diperoleh melalui website <a href="https://nylestari.com/" target="_blank">https://nylestari.com/</a>.</p>
      
      <p>Dengan mengakses dan menggunakan website ini, Anda dianggap telah membaca dan memahami Kebijakan Privasi ini.</p>

      <h2>1. Informasi yang Kami Kumpulkan</h2>
      <p>Kami dapat memperoleh beberapa jenis informasi dari pengunjung website, antara lain:</p>
      
      <h3>A. Informasi yang diberikan secara langsung</h3>
      <p>Apabila Anda menghubungi kami melalui formulir kontak, WhatsApp, email, atau media komunikasi lainnya, kami dapat menerima informasi seperti:</p>
      <ul>
        <li>Nama</li>
        <li>Nomor telepon atau WhatsApp</li>
        <li>Alamat email</li>
        <li>Alamat pengiriman, apabila diperlukan untuk pemesanan</li>
        <li>Informasi mengenai produk atau pesanan</li>
        <li>Informasi lain yang secara sukarela Anda berikan kepada kami</li>
      </ul>

      <h3>B. Informasi yang dikumpulkan secara otomatis</h3>
      <p>Ketika Anda mengunjungi Nylestari.com, beberapa informasi teknis dapat dikumpulkan secara otomatis, seperti:</p>
      <ul>
        <li>Alamat IP</li>
        <li>Jenis perangkat</li>
        <li>Jenis browser</li>
        <li>Sistem operasi</li>
        <li>Halaman yang dikunjungi</li>
        <li>Waktu dan durasi kunjungan</li>
      </ul>

      <h2>2. Penggunaan Informasi</h2>
      <p>Informasi yang kami peroleh dapat digunakan untuk:</p>
      <ul>
        <li>Memberikan informasi mengenai produk Sambel Pecel Nylestari.</li>
        <li>Menanggapi pertanyaan atau permintaan dari pengunjung.</li>
        <li>Memproses komunikasi atau pemesanan apabila tersedia.</li>
        <li>Memberikan pelayanan kepada pelanggan.</li>
        <li>Meningkatkan kualitas, keamanan, dan performa website.</li>
      </ul>

      <h2>3. Hubungi Kami</h2>
      <p>Apabila Anda memiliki pertanyaan terkait Kebijakan Privasi, silakan hubungi kami di <a href="https://nylestari.com/">https://nylestari.com/</a>.</p>
    </div>
  </div>
</div>

<!-- STYLE MODAL PRIVACY -->
<style>
    a.privacy-link {
        color: var(--footer-text-white) !important;
        text-decoration: underline;
        font-weight: bold;
        cursor: pointer;
    }

    a.privacy-link:hover {
        color: #FFD700 !important;
    }

    .privacy-modal {
        display: none;
        position: fixed;
        z-index: 2000;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        overflow: auto;
        background-color: rgba(0,0,0,0.6);
    }

    .privacy-modal-content {
        background-color: #fefefe;
        margin: 5% auto;
        padding: 30px;
        border: 1px solid #888;
        width: 80%;
        max-width: 800px;
        border-radius: 8px;
        position: relative;
        max-height: 80vh;
        overflow-y: auto;
        color: #333;
    }

    .privacy-modal-close {
        color: #aaa;
        float: right;
        font-size: 28px;
        font-weight: bold;
        cursor: pointer;
    }

    .privacy-modal-close:hover,
    .privacy-modal-close:focus {
        color: black;
        text-decoration: none;
    }

    .privacy-body h1, .privacy-body h2, .privacy-body h3 {
        margin-top: 15px;
        margin-bottom: 10px;
        color: var(--dark-color);
    }

    .privacy-body p, .privacy-body ul {
        margin-bottom: 10px;
    }

    .privacy-body ul {
        padding-left: 20px;
    }
</style>

<!-- SCRIPT FIX: Deklarasi fungsi di Scope Global secara eksplisit -->
<script>
    function openPrivacyModal() {
        var modal = document.getElementById("privacyModal");
        if (modal) {
            modal.style.display = "block";
        }
    }

    function closePrivacyModal() {
        var modal = document.getElementById("privacyModal");
        if (modal) {
            modal.style.display = "none";
        }
    }

    window.addEventListener('click', function(event) {
        var modal = document.getElementById("privacyModal");
        if (event.target === modal) {
            modal.style.display = "none";
        }
    });
</script>
</body>
</html>