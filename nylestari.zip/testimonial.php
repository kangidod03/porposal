<!DOCTYPE html>
<html lang="id">

<head>

    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());

      gtag('config', 'G-L2XL4CEVBD');
    </script>
    <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-3541147626555936"
      crossorigin="anonymous"></script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Primary Meta Tags -->
    <title>Testimonial - Sambal Pecel Ny Lestari</title>
    <meta name="title" content="Testimonial - Sambal Pecel Ny Lestari">
    <meta name="description" content="Kata mereka tentang Sambal Pecel Ny Lestari khas Kediri asli warisan resep Jawa Timur. Simak pengalaman dari para pelanggan setia kami.">
    <meta name="keywords" content="testimonial sambal pecel, ulasan sambal pecel, bumbu pecel kediri, sambal pecel ny lestari">
    <meta name="robots" content="index, follow">
    <meta name="language" content="Indonesian">
    <meta name="author" content="Ny Lestari">
    <link rel="canonical" href="https://nylestari.com/halaman_testimonial.html">

    <!-- Favicon -->
    <link rel="icon" type="image/jpeg" href="logo-lestari.jpg">
    <link rel="apple-touch-icon" href="logo-lestari.jpg">

    <!-- Fonts & Icons -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&family=Playfair+Display:wght@700&family=Caveat:wght@600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <style>
        :root {
            --primary-color: #C0392B;
            --secondary-color: #E67E22;
            --dark-color: #2C3E50;
            --light-color: #FDFEFE;
            --accent-color: #27AE60;
            --nu-green: #008542; /* Hijau khas NU */
            --footer-text-white: #FFFFFF; /* Teks Putih Bersih */
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            color: #333;
            background-color: #FAFAFA;
            line-height: 1.6;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        header {
            background-color: var(--light-color);
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            position: fixed;
            width: 100%;
            top: 0;
            z-index: 1000;
        }

        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            max-width: 1200px;
            margin: 0 auto;
            padding: 10px 20px;
        }

        .logo-container {
            display: flex;
            align-items: center;
            gap: 16px;
            text-decoration: none;
        }

        .logo-img {
            height: 90px;
            width: 90px;
            border-radius: 50%;
            object-fit: cover;
        }

        .logo-text {
            font-family: 'Playfair Display', serif;
            font-size: 48px;
            font-weight: 700;
            color: var(--primary-color);
        }

        .nav-links {
            display: flex;
            list-style: none;
            gap: 25px;
            align-items: center;
        }

        .nav-links a {
            text-decoration: none;
            color: var(--dark-color);
            font-weight: 500;
            transition: color 0.3s;
        }

        .nav-links a:hover {
            color: var(--primary-color);
        }

        .btn-order {
            background-color: var(--primary-color);
            color: white !important;
            padding: 8px 20px;
            border-radius: 25px;
            font-weight: 600 !important;
            transition: background 0.3s;
        }

        .btn-order:hover {
            background-color: #A93226 !important;
        }

        /* Testimonial Page Styles */
        .page-banner {
            margin-top: 110px;
            background-color: var(--primary-color);
            color: white;
            padding: 50px 20px;
            text-align: center;
        }

        .page-banner h1 {
            font-family: 'Playfair Display', serif;
            font-size: 36px;
            margin-bottom: 10px;
        }

        .page-banner p {
            font-size: 16px;
            max-width: 700px;
            margin: 0 auto;
            opacity: 0.9;
        }

        .testimonial-container {
            max-width: 900px;
            margin: 40px auto;
            padding: 0 20px;
            flex-grow: 1;
        }

        .testimonial-card {
            background: white;
            padding: 25px 30px;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.05);
            border: 1px solid #f0f0f0;
            margin-bottom: 25px;
            transition: transform 0.2s;
        }

        .testimonial-card:hover {
            transform: translateY(-3px);
        }

        .font-handwriting {
            font-family: 'Caveat', cursive;
            font-size: 26px;
            color: var(--primary-color);
            margin-bottom: 12px;
            padding-bottom: 8px;
            border-bottom: 1px dashed #eee;
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            align-items: center;
        }

        .testimonial-text {
            font-style: italic;
            color: #555;
            line-height: 1.7;
        }

        /* ==================== STYLES FOOTER (HIJAU NU & TEKS PUTIH) ==================== */
        footer {
            background-color: var(--nu-green); /* Hijau Khas NU */
            color: var(--footer-text-white); /* Teks Putih */
            padding: 50px 20px 20px 20px;
            font-size: 15px;
        }

        .footer-container {
            max-width: 1200px;
            margin: 0 auto;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 40px;
            padding-bottom: 40px;
        }

        .footer-col h3 {
            font-family: 'Playfair Display', serif;
            font-size: 22px;
            font-weight: 700;
            letter-spacing: 1px;
            margin-bottom: 20px;
            text-transform: uppercase;
            color: var(--footer-text-white); /* Putih */
        }

        .footer-col p {
            line-height: 1.7;
            color: var(--footer-text-white); /* Putih */
            font-weight: 400;
        }

        .footer-contact-item {
            display: flex;
            align-items: flex-start;
            gap: 12px;
            margin-bottom: 15px;
            color: var(--footer-text-white); /* Putih */
            font-weight: 400;
        }

        .footer-contact-item i {
            font-size: 18px;
            margin-top: 3px;
            color: var(--footer-text-white); /* Putih */
        }

        .footer-socials {
            display: flex;
            gap: 15px;
        }

        .footer-socials a {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 42px;
            height: 42px;
            background-color: rgba(255, 255, 255, 0.15); /* Background transparan putih */
            color: var(--footer-text-white); /* Putih */
            border-radius: 8px;
            font-size: 20px;
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .footer-socials a:hover {
            background-color: #ffffff;
            color: var(--nu-green);
            transform: translateY(-3px);
        }

        .footer-bottom {
            max-width: 1200px;
            margin: 0 auto;
            border-top: 1px solid rgba(255, 255, 255, 0.2);
            padding-top: 25px;
            text-align: center;
            font-size: 14px;
            color: var(--footer-text-white); /* Putih */
            font-weight: 400;
        }

        @media (max-width: 768px) {
            .nav-links { display: none; }
            .logo-img { height: 60px; width: 60px; }
            .logo-text { font-size: 30px; }
            .footer-container { text-align: left; }
            .page-banner h1 { font-size: 28px; }
        }
    </style>
</head>

<body>

    <!-- Header & Navigation -->
    <header>
        <nav class="navbar" aria-label="Navigasi Utama">
            <a href="index.php" class="logo-container">
                <img src="logo-lestari.jpg" alt="Logo Sambal Pecel Ny Lestari Kediri" class="logo-img" width="90" height="90">
                <span class="logo-text">Ny Lestari</span>
            </a>
            <ul class="nav-links">
                <li><a href="index.php">Beranda</a></li>
                <li><a href="index.php#tentang">Keunggulan</a></li>
                <li><a href="index.php#produk">Produk</a></li>
                <li><a href="testimonial.php">Testimonial</a></li>
                <li><a href="berita.php">Berita Terbaru</a></li>
                <li><a href="https://wa.me/6282220468952?text=Halo,%20saya%20ingin%20memesan%20Sambal%20Pecel%20Ny%20Lestari%20Khas%20Kediri." target="_blank" rel="noopener noreferrer" class="btn-order"><i class="fab fa-whatsapp"></i> Beli Sekarang</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <!-- Page Banner -->
        <section class="page-banner">
            <h1>Kata Mereka Tentang Ny Lestari</h1>
            <p>Pengalaman asli dari para pelanggan setia pencinta cita rasa otentik sambal pecel khas Kediri.</p>
        </section>

        <!-- Main Testimonials List -->
        <div class="testimonial-container">

            <!-- 1 -->
            <article class="testimonial-card">
                <div class="font-handwriting">
                    <span>12 Mei 2026</span>
                    <span>•</span>
                    <span>Surabaya</span>
                    <span>•</span>
                    <span>Bu Rina Sulistyo</span>
                </div>
                <p class="testimonial-text">
                    "Bumbu pecel Ny Lestari iki rasane pas banget ing lidah! Kacang goreng sangraine krasa gurih lan ora marakne tenggorokan serak. Pedase sedhep, cocok disantap karo sega anget lan rempeyek. Wis dadi langganan keluarga pas acara kumpul-kumpul."
                </p>
            </article>

            <!-- 2 -->
            <article class="testimonial-card">
                <div class="font-handwriting">
                    <span>28 April 2026</span>
                    <span>•</span>
                    <span>Jakarta Selatan</span>
                    <span>•</span>
                    <span>Mas Hendra Setiawan</span>
                </div>
                <p class="testimonial-text">
                    "Kangen kulineran kampung halaman di Kediri akhirnya terobati! Tekstur bumbunya legit, minyak kacangnya alami, dan daun jeruknya wangi banget. Praktis tinggal diseduh air hangat. Pengiriman ke Jakarta juga cepat dan kemasannya sangat aman."
                </p>
            </article>

            <!-- 3 -->
            <article class="testimonial-card">
                <div class="font-handwriting">
                    <span>15 Maret 2026</span>
                    <span>•</span>
                    <span>Malang</span>
                    <span>•</span>
                    <span>Mbak Anita Putri</span>
                </div>
                <p class="testimonial-text">
                    "Suka banget sama varian sambal pecel pedas sedangnya. Rasanya seimbang antara manis gurihnya gula jawa dan pedas cabainya. Cocok juga buat bumbu gado-gado atau cocolan tahu goreng hangat. Bikin nambah porsi makan melulu!"
                </p>
            </article>

            <!-- 4 -->
            <article class="testimonial-card">
                <div class="font-handwriting">
                    <span>02 Maret 2026</span>
                    <span>•</span>
                    <span>Bandung</span>
                    <span>•</span>
                    <span>Pak Budi Santoso</span>
                </div>
                <p class="testimonial-text">
                    "Saya bawa bumbu pecel Ny Lestari untuk oleh-oleh kerabat di Sunda dan ternyata mereka suka sekali. Aroma kencur dan daun jeruknya sangat segar. Produknya awet disimpan di kulkas tanpa mengurangi cita rasanya."
                </p>
            </article>

            <!-- 5 -->
            <article class="testimonial-card">
                <div class="font-handwriting">
                    <span>19 Februari 2026</span>
                    <span>•</span>
                    <span>Semarang</span>
                    <span>•</span>
                    <span>Ibu Sri Rahayu</span>
                </div>
                <p class="testimonial-text">
                    "Luar biasa rasanya! Rasa gurih manis kacangnya benar-benar otentik resep tradisional khas Jawa Timuran. Praktis buat sarapan anak-anak sebelum sekolah, tinggal siram air panas langsung siap disajikan."
                </p>
            </article>

            <!-- 6 -->
            <article class="testimonial-card">
                <div class="font-handwriting">
                    <span>05 Februari 2026</span>
                    <span>•</span>
                    <span>Kediri</span>
                    <span>•</span>
                    <span>Mas Dimas Pratama</span>
                </div>
                <p class="testimonial-text">
                    "Sebagai warga asli Kediri, saya acung jempol buat kualitas bumbu pecel Ny Lestari. Bahan-bahannya kelihatan memakai kualitas super, kacangnya tidak apek dan renyah. Sukses terus buat Ny Lestari!"
                </p>
            </article>

            <!-- 7 -->
            <article class="testimonial-card">
                <div class="font-handwriting">
                    <span>21 Januari 2026</span>
                    <span>•</span>
                    <span>Yogyakarta</span>
                    <span>•</span>
                    <span>Mbak Maya Kusuma</span>
                </div>
                <p class="testimonial-text">
                    "Sambal pecel terbaik yang pernah saya pesan secara online. Kemasannya rapi, kedap udara, dan higienis. Rasanya konsisten dari pesanan pertama sampai sekarang. Mantap tenan!"
                </p>
            </article>

            <!-- 8 -->
            <article class="testimonial-card">
                <div class="font-handwriting">
                    <span>10 Januari 2026</span>
                    <span>•</span>
                    <span>Sidoarjo</span>
                    <span>•</span>
                    <span>Pak Agung Kurniadi</span>
                </div>
                <p class="testimonial-text">
                    "Variasi super pedasnya benar-benar menantang! Pedasnya nampol tapi tidak mengikis rasa gurih kacangnya. Buat pencinta pedas wajib coba varian yang satu ini."
                </p>
            </article>

            <!-- 9 -->
            <article class="testimonial-card">
                <div class="font-handwriting">
                    <span>28 Desember 2025</span>
                    <span>•</span>
                    <span>Denpasar</span>
                    <span>•</span>
                    <span>Ibu Ni Made Wardani</span>
                </div>
                <p class="testimonial-text">
                    "Setiap kali kangen masakan Jawa, sambal pecel Ny Lestari selalu jadi penyelamat. Disiram ke bayam, kangkung, dan tauge rebus rasanya luar biasa nikmat."
                </p>
            </article>

            <!-- 10 -->
            <article class="testimonial-card">
                <div class="font-handwriting">
                    <span>14 Desember 2025</span>
                    <span>•</span>
                    <span>Tangerang</span>
                    <span>•</span>
                    <span>Mas Rizky Febrian</span>
                </div>
                <p class="testimonial-text">
                    "Awalnya coba-coba beli 2 bungkus, eh ternyata sekeluarga langsung suka. Bumbunya gampang larut dan teksturnya tidak terlalu kental atau encer saat diseduh. Next pasti order lagi."
                </p>
            </article>

            <!-- 11 -->
            <article class="testimonial-card">
                <div class="font-handwriting">
                    <span>01 Desember 2025</span>
                    <span>•</span>
                    <span>Gresik</span>
                    <span>•</span>
                    <span>Mbak Dewi Anggraini</span>
                </div>
                <p class="testimonial-text">
                    "Sangat cocok dijadikan stok persediaan lauk di rumah. Suami dan anak-anak tidak pernah bosan kalau makan pecel pakai bumbu Ny Lestari ini."
                </p>
            </article>

            <!-- 12 -->
            <article class="testimonial-card">
                <div class="font-handwriting">
                    <span>18 November 2025</span>
                    <span>•</span>
                    <span>Bekasi</span>
                    <span>•</span>
                    <span>Pak Wahyu Hidayat</span>
                </div>
                <p class="testimonial-text">
                    "Pelayanannya cepat dan ramah, bumbu pecelnya masih sangat segar pas sampai. Rasa kacang tanahnya manis gurih dan tidak ada pahitnya sama sekali."
                </p>
            </article>

            <!-- 13 -->
            <article class="testimonial-card">
                <div class="font-handwriting">
                    <span>05 November 2025</span>
                    <span>•</span>
                    <span>Surakarta</span>
                    <span>•</span>
                    <span>Ibu Eni Astuti</span>
                </div>
                <p class="testimonial-text">
                    "Racikan rempahnya terasa komplit dan harum. Kualitas rasa konsisten dan tidak banyak minyak menggenang. Sangat direkomendasikan!"
                </p>
            </article>

            <!-- 14 -->
            <article class="testimonial-card">
                <div class="font-handwriting">
                    <span>22 Oktober 2025</span>
                    <span>•</span>
                    <span>Depok</span>
                    <span>•</span>
                    <span>Mas Fajar Nugroho</span>
                </div>
                <p class="testimonial-text">
                    "Pilihan tepat buat anak kos yang mau makan enak dan sehat tanpa ribet. Tinggal rebus sayur sebentar, tuang bumbu Ny Lestari, nikmat tiada tara!"
                </p>
            </article>

            <!-- 15 -->
            <article class="testimonial-card">
                <div class="font-handwriting">
                    <span>10 Oktober 2025</span>
                    <span>•</span>
                    <span>Madiun</span>
                    <span>•</span>
                    <span>Ibu Endang Lestari</span>
                </div>
                <p class="testimonial-text">
                    "Meskipun saya tinggal di kota pecel, rasa bumbu pecel Ny Lestari khas Kediri ini punya keunikan tersendiri yang sangat lezat dan bikin ketagihan!"
                </p>
            </article>

        </div>
    </main>

    <!-- FOOTER 3 KOLOM (HIJAU NU & TEKS PUTIH) -->
    <footer>
        <div class="footer-container">
            <!-- Kolom 1: Tentang -->
            <div class="footer-col">
                <h3>NY LESTARI</h3>
                <p>Kami adalah produsen Sambal Pecel khas Kediri yang didedikasikan untuk menyajikan kelezatan bumbu pecel berkualitas tinggi, dibuat dari bahan-bahan terbaik dan resep warisan otentik Jawa Timur.</p>
            </div>

            <!-- Kolom 2: Kontak -->
            <div class="footer-col">
                <h3>KONTAK</h3>
                <div class="footer-contact-item">
                    <i class="fas fa-map-marker-alt"></i>
                    <span>Jl Sawo, Desa Pelem - Kertosono, Jawa Timur, 64314</span>
                </div>
                <div class="footer-contact-item">
                    <i class="fas fa-phone-alt"></i>
                    <span>0822 2046 8952</span>
                </div>
            </div>

            <!-- Kolom 3: Sosial Media -->
            <div class="footer-col">
                <h3>IKUTI KAMI</h3>
                <div class="footer-socials">
                    <a href="https://www.instagram.com/nylestari_com/" target="_blank" aria-label="Instagram"><i class="fab fa-instagram"></i></a>
                    <a href="#" target="_blank" aria-label="TikTok"><i class="fab fa-tiktok"></i></a>
                </div>
            </div>
        </div>

        <!-- Copyright & Privacy Policy -->
        <div class="footer-bottom">
            <p>&copy; 2026 Copyright: <strong>Nylestari.com</strong> | <a href="javascript:void(0)" onclick="openPrivacyModal()" class="privacy-link">Kebijakan Privasi</a></p>
        </div>
    </footer>

    <!-- STRUKTUR MODAL POP-UP KEBIJAKAN PRIVASI -->
    <div id="privacyModal" class="privacy-modal">
      <div class="privacy-modal-content">
        <span class="privacy-modal-close" onclick="closePrivacyModal()">&times;</span>
        
        <div class="privacy-body">
          <h1>KEBIJAKAN PRIVASI</h1>
          <p><strong>Terakhir diperbarui:</strong> 26 September 2026</p>
          
          <p>Selamat datang di Nylestari.com, website yang menyediakan informasi dan layanan terkait Sambel Pecel Nylestari, produk makanan, informasi produk, serta informasi lain yang berkaitan dengan usaha kami.</p>
          
          <p>Kami menghargai privasi setiap pengunjung website. Kebijakan Privasi ini menjelaskan bagaimana kami mengumpulkan, menggunakan, menyimpan, dan melindungi informasi yang diperoleh melalui website <a href="https://nylestari.com/" target="_blank">https://nylestari.com/</a>.</p>
          
          <p>Dengan mengakses dan menggunakan website ini, Anda dianggap telah membaca dan memahami Kebijakan Privasi ini.</p>

          <h2>1. Informasi yang Kami Kumpulkan</h2>
          <p>Kami dapat memperoleh beberapa jenis informasi dari pengunjung website, antara lain:</p>
          
          <h3>A. Informasi yang diberikan secara langsung</h3>
          <p>Apabila Anda menghubungi kami melalui formulir kontak, WhatsApp, email, atau media komunikasi lainnya, kami dapat menerima informasi seperti:</p>
          <ul>
            <li>Nama</li>
            <li>Nomor telepon atau WhatsApp</li>
            <li>Alamat email</li>
            <li>Alamat pengiriman, apabila diperlukan untuk pemesanan</li>
            <li>Informasi mengenai produk atau pesanan</li>
            <li>Informasi lain yang secara sukarela Anda berikan kepada kami</li>
          </ul>

          <h3>B. Informasi yang dikumpulkan secara otomatis</h3>
          <p>Ketika Anda mengunjungi Nylestari.com, beberapa informasi teknis dapat dikumpulkan secara otomatis, seperti:</p>
          <ul>
            <li>Alamat IP</li>
            <li>Jenis perangkat</li>
            <li>Jenis browser</li>
            <li>Sistem operasi</li>
            <li>Halaman yang dikunjungi</li>
            <li>Waktu dan durasi kunjungan</li>
          </ul>

          <h2>2. Penggunaan Informasi</h2>
          <p>Informasi yang kami peroleh dapat digunakan untuk:</p>
          <ul>
            <li>Memberikan informasi mengenai produk Sambel Pecel Nylestari.</li>
            <li>Menanggapi pertanyaan atau permintaan dari pengunjung.</li>
            <li>Memproses komunikasi atau pemesanan apabila tersedia.</li>
            <li>Memberikan pelayanan kepada pelanggan.</li>
            <li>Meningkatkan kualitas, keamanan, dan performa website.</li>
          </ul>

          <h2>3. Hubungi Kami</h2>
          <p>Apabila Anda memiliki pertanyaan terkait Kebijakan Privasi, silakan hubungi kami di <a href="https://nylestari.com/">https://nylestari.com/</a>.</p>
        </div>
      </div>
    </div>

    <!-- STYLE & SCRIPT MODAL PRIVACY -->
    <style>
        a.privacy-link {
            color: var(--footer-text-white) !important;
            text-decoration: underline;
            font-weight: bold;
        }

        a.privacy-link:hover {
            color: #FFD700 !important;
        }

        .privacy-modal {
            display: none;
            position: fixed;
            z-index: 2000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0,0,0,0.6);
        }

        .privacy-modal-content {
            background-color: #fefefe;
            margin: 5% auto;
            padding: 30px;
            border: 1px solid #888;
            width: 80%;
            max-width: 800px;
            border-radius: 8px;
            position: relative;
            max-height: 80vh;
            overflow-y: auto;
            color: #333;
        }

        .privacy-modal-close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
        }

        .privacy-modal-close:hover,
        .privacy-modal-close:focus {
            color: black;
            text-decoration: none;
        }

        .privacy-body h1, .privacy-body h2, .privacy-body h3 {
            margin-top: 15px;
            margin-bottom: 10px;
            color: var(--dark-color);
        }

        .privacy-body p, .privacy-body ul {
            margin-bottom: 10px;
        }

        .privacy-body ul {
            padding-left: 20px;
        }
    </style>

    <script>
        function openPrivacyModal() {
            document.getElementById("privacyModal").style.display = "block";
        }

        function closePrivacyModal() {
            document.getElementById("privacyModal").style.display = "none";
        }

        window.onclick = function(event) {
            var modal = document.getElementById("privacyModal");
            if (event.target == modal) {
                modal.style.display = "none";
            }
        }
    </script>
</body>

</html>