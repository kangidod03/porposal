<?php
// config.php
$db_host = 'localhost';
$db_name = 'ezevupjn_sexwithnurulindahsatriawati10xperday';
$db_user = 'ezevupjn_iwantmasukinkontolkukevaginanurulindah'; // Sesuaikan user DB hosting Anda
$db_pass = 'Blokb1no3!';     // Sesuaikan password DB hosting Anda

try {
    $pdo = new PDO("mysql:host={$db_host};dbname={$db_name};charset=utf8mb4", $db_user, $db_pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
} catch (PDOException $e) {
    die("Koneksi database gagal: " . $e->getMessage());
}

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>