<!DOCTYPE html>
<html lang="id">

<head>

    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());

      gtag('config', 'G-L2XL4CEVBD');
    </script>
    <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-3541147626555936"
      crossorigin="anonymous"></script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Primary Meta Tags -->
    <title>Berita & Artikel - Sambal Pecel Ny Lestari</title>
    <meta name="title" content="Berita & Artikel - Sambal Pecel Ny Lestari">
    <meta name="description" content="Informasi terbaru seputar kegiatan, resep, tips, dan ragam cerita dari Sambal Pecel Ny Lestari khas Kediri asli warisan resep Jawa Timur.">
    <meta name="keywords" content="berita sambal pecel, resep pecel kediri, artikel bumbu pecel, sambal pecel ny lestari">
    <meta name="robots" content="index, follow">
    <meta name="language" content="Indonesian">
    <meta name="author" content="Ny Lestari">
    <link rel="canonical" href="https://nylestari.com/berita.php">

    <!-- Favicon -->
    <link rel="icon" type="image/jpeg" href="logo-lestari.jpg">
    <link rel="apple-touch-icon" href="logo-lestari.jpg">

    <!-- Fonts & Icons -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&family=Playfair+Display:wght@700&family=Caveat:wght@600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <!-- Tailwind CSS (Digunakan khusus untuk Layout & Grid Konten Berita) -->
    <script src="https://cdn.tailwindcss.com"></script>

    <style>
        :root {
            --primary-color: #C0392B;
            --secondary-color: #E67E22;
            --dark-color: #2C3E50;
            --light-color: #FDFEFE;
            --accent-color: #27AE60;
            --nu-green: #008542; /* Hijau khas NU */
            --footer-text-white: #FFFFFF; /* Teks Putih Bersih */
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            color: #333;
            background-color: #FAFAFA;
            line-height: 1.6;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        header {
            background-color: var(--light-color);
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            position: fixed;
            width: 100%;
            top: 0;
            z-index: 1000;
        }

        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            max-width: 1200px;
            margin: 0 auto;
            padding: 10px 20px;
        }

        .logo-container {
            display: flex;
            align-items: center;
            gap: 16px;
            text-decoration: none;
        }

        .logo-img {
            height: 90px;
            width: 90px;
            border-radius: 50%;
            object-fit: cover;
        }

        .logo-text {
            font-family: 'Playfair Display', serif;
            font-size: 48px;
            font-weight: 700;
            color: var(--primary-color);
        }

        .nav-links {
            display: flex;
            list-style: none;
            gap: 25px;
            align-items: center;
        }

        .nav-links a {
            text-decoration: none;
            color: var(--dark-color);
            font-weight: 500;
            transition: color 0.3s;
        }

        .nav-links a:hover {
            color: var(--primary-color);
        }

        .btn-order {
            background-color: var(--primary-color);
            color: white !important;
            padding: 8px 20px;
            border-radius: 25px;
            font-weight: 600 !important;
            transition: background 0.3s;
        }

        .btn-order:hover {
            background-color: #A93226 !important;
        }

        /* Banner Styles */
        .page-banner {
            margin-top: 110px;
            background-color: var(--primary-color);
            color: white;
            padding: 50px 20px;
            text-align: center;
        }

        .page-banner h1 {
            font-family: 'Playfair Display', serif;
            font-size: 36px;
            margin-bottom: 10px;
        }

        .page-banner p {
            font-size: 16px;
            max-width: 700px;
            margin: 0 auto;
            opacity: 0.9;
        }

        /* ==================== STYLES FOOTER (HIJAU NU & TEKS PUTIH) ==================== */
        footer {
            background-color: var(--nu-green); /* Hijau Khas NU */
            color: var(--footer-text-white); /* Teks Putih */
            padding: 50px 20px 20px 20px;
            font-size: 15px;
        }

        .footer-container {
            max-width: 1200px;
            margin: 0 auto;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 40px;
            padding-bottom: 40px;
        }

        .footer-col h3 {
            font-family: 'Playfair Display', serif;
            font-size: 22px;
            font-weight: 700;
            letter-spacing: 1px;
            margin-bottom: 20px;
            text-transform: uppercase;
            color: var(--footer-text-white); /* Putih */
        }

        .footer-col p {
            line-height: 1.7;
            color: var(--footer-text-white); /* Putih */
            font-weight: 400;
        }

        .footer-contact-item {
            display: flex;
            align-items: flex-start;
            gap: 12px;
            margin-bottom: 15px;
            color: var(--footer-text-white); /* Putih */
            font-weight: 400;
        }

        .footer-contact-item i {
            font-size: 18px;
            margin-top: 3px;
            color: var(--footer-text-white); /* Putih */
        }

        .footer-socials {
            display: flex;
            gap: 15px;
        }

        .footer-socials a {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 42px;
            height: 42px;
            background-color: rgba(255, 255, 255, 0.15); /* Background transparan putih */
            color: var(--footer-text-white); /* Putih */
            border-radius: 8px;
            font-size: 20px;
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .footer-socials a:hover {
            background-color: #ffffff;
            color: var(--nu-green);
            transform: translateY(-3px);
        }

        .footer-bottom {
            max-width: 1200px;
            margin: 0 auto;
            border-top: 1px solid rgba(255, 255, 255, 0.2);
            padding-top: 25px;
            text-align: center;
            font-size: 14px;
            color: var(--footer-text-white); /* Putih */
            font-weight: 400;
        }

        @media (max-width: 768px) {
            .nav-links { display: none; }
            .logo-img { height: 60px; width: 60px; }
            .logo-text { font-size: 30px; }
            .footer-container { text-align: left; }
            .page-banner h1 { font-size: 28px; }
        }
    </style>
</head>

<body>

    <!-- Header & Navigation -->
    <header>
        <nav class="navbar" aria-label="Navigasi Utama">
            <a href="index.php" class="logo-container">
                <img src="logo-lestari.jpg" alt="Logo Sambal Pecel Ny Lestari Kediri" class="logo-img" width="90" height="90">
                <span class="logo-text">Ny Lestari</span>
            </a>
            <ul class="nav-links">
                <li><a href="index.php">Beranda</a></li>
                <li><a href="index.php#tentang">Keunggulan</a></li>
                <li><a href="index.php#produk">Produk</a></li>
                <li><a href="testimonial.php">Testimonial</a></li>
                <li><a href="berita.php">Berita Terbaru</a></li>
                <li><a href="https://wa.me/6282220468952?text=Halo,%20saya%20ingin%20memesan%20Sambal%20Pecel%20Ny%20Lestari%20Khas%20Kediri." target="_blank" rel="noopener noreferrer" class="btn-order"><i class="fab fa-whatsapp"></i> Beli Sekarang</a></li>
            </ul>
        </nav>
    </header>

    <main class="flex-grow">
        <!-- Page Banner -->
        <section class="page-banner">
            <h1>Berita & Artikel Terbaru</h1>
            <p>Informasi terbaru seputar kegiatan, resep, dan ragam cerita dari Sambal Pecel Ny Lestari.</p>
        </section>

        <!-- News Grid (2 Kolom) -->
        <div class="max-w-6xl mx-auto px-4 py-12">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-8">

                <!-- Berita 1 -->
                <article onclick="openModal(1)" class="bg-white rounded-2xl overflow-hidden shadow-sm border border-red-100 hover:shadow-lg transition cursor-pointer group flex flex-col">
                    <img src="https://images.unsplash.com/photo-1596560548464-f010549b84d7?auto=format&fit=crop&w=800&q=80" alt="Resep Warisan Kediri" class="w-full h-56 object-cover group-hover:scale-105 transition duration-300">
                    <div class="p-6 flex flex-col flex-grow">
                        <div class="text-xs font-semibold text-[#C0392B] flex items-center gap-4 mb-3">
                            <span><i class="fa-regular fa-user me-1"></i> Admin</span>
                            <span><i class="fa-regular fa-calendar me-1"></i> 20 Mei 2026</span>
                        </div>
                        <h2 class="text-xl font-bold text-gray-900 group-hover:text-[#C0392B] transition mb-3">
                            Rahasia Dibalik Kelezatan Bumbu Pecel Otentik Khas Kediri
                        </h2>
                        <p class="text-gray-600 text-sm line-clamp-3 mb-4">
                            Kuliner pecel telah menjadi salah satu identitas kekayaan rasa khas Jawa Timur. Dibalik gurih nikmatnya Sambal Pecel Ny Lestari, terdapat proses pemilihan bahan baku lokal berkualitas tinggi secara ketat...
                        </p>
                        <span class="mt-auto text-[#C0392B] font-medium text-sm flex items-center gap-1 group-hover:underline">
                            Baca Selengkapnya <i class="fa-solid fa-arrow-right text-xs"></i>
                        </span>
                    </div>
                </article>

                <!-- Berita 2 -->
                <article onclick="openModal(2)" class="bg-white rounded-2xl overflow-hidden shadow-sm border border-red-100 hover:shadow-lg transition cursor-pointer group flex flex-col">
                    <img src="https://images.unsplash.com/photo-1613564834361-9436948817d1?auto=format&fit=crop&w=800&q=80" alt="Kemasan Kedap Udara" class="w-full h-56 object-cover group-hover:scale-105 transition duration-300">
                    <div class="p-6 flex flex-col flex-grow">
                        <div class="text-xs font-semibold text-[#C0392B] flex items-center gap-4 mb-3">
                            <span><i class="fa-regular fa-user me-1"></i> Admin</span>
                            <span><i class="fa-regular fa-calendar me-1"></i> 10 April 2026</span>
                        </div>
                        <h2 class="text-xl font-bold text-gray-900 group-hover:text-[#C0392B] transition mb-3">
                            Ny Lestari Luncurkan Kemasan Praktis Kedap Udara Tahan Lama
                        </h2>
                        <p class="text-gray-600 text-sm line-clamp-3 mb-4">
                            Memenuhi tingginya permintaan pelanggan yang ingin membawa sambal pecel sebagai oleh-oleh ke luar kota hingga luar negeri, Ny Lestari resmi menghadirkan teknologi kemasan vakum mutakhir...
                        </p>
                        <span class="mt-auto text-[#C0392B] font-medium text-sm flex items-center gap-1 group-hover:underline">
                            Baca Selengkapnya <i class="fa-solid fa-arrow-right text-xs"></i>
                        </span>
                    </div>
                </article>

                <!-- Berita 3 -->
                <article onclick="openModal(3)" class="bg-white rounded-2xl overflow-hidden shadow-sm border border-red-100 hover:shadow-lg transition cursor-pointer group flex flex-col">
                    <img src="https://images.unsplash.com/photo-1540420773420-3366772f4999?auto=format&fit=crop&w=800&q=80" alt="Manfaat Sayuran Pecel" class="w-full h-56 object-cover group-hover:scale-105 transition duration-300">
                    <div class="p-6 flex flex-col flex-grow">
                        <div class="text-xs font-semibold text-[#C0392B] flex items-center gap-4 mb-3">
                            <span><i class="fa-regular fa-user me-1"></i> Admin</span>
                            <span><i class="fa-regular fa-calendar me-1"></i> 18 Maret 2026</span>
                        </div>
                        <h2 class="text-xl font-bold text-gray-900 group-hover:text-[#C0392B] transition mb-3">
                            Tips Menyajikan Pecel Segar dan Sehat untuk Sarapan Keluarga
                        </h2>
                        <p class="text-gray-600 text-sm line-clamp-3 mb-4">
                            Sarapan seimbang adalah kunci utama energi harian. Kombinasi sayuran rebus seperti kangkung, bayam, dan tauge disiram sambal pecel olahan kacang tanah sangrai menjadi menu kaya nutrisi...
                        </p>
                        <span class="mt-auto text-[#C0392B] font-medium text-sm flex items-center gap-1 group-hover:underline">
                            Baca Selengkapnya <i class="fa-solid fa-arrow-right text-xs"></i>
                        </span>
                    </div>
                </article>

                <!-- Berita 4 -->
                <article onclick="openModal(4)" class="bg-white rounded-2xl overflow-hidden shadow-sm border border-red-100 hover:shadow-lg transition cursor-pointer group flex flex-col">
                    <img src="https://images.unsplash.com/photo-1555396273-367ea4eb4db5?auto=format&fit=crop&w=800&q=80" alt="Festival Kuliner" class="w-full h-56 object-cover group-hover:scale-105 transition duration-300">
                    <div class="p-6 flex flex-col flex-grow">
                        <div class="text-xs font-semibold text-[#C0392B] flex items-center gap-4 mb-3">
                            <span><i class="fa-regular fa-user me-1"></i> Admin</span>
                            <span><i class="fa-regular fa-calendar me-1"></i> 25 Februari 2026</span>
                        </div>
                        <h2 class="text-xl font-bold text-gray-900 group-hover:text-[#C0392B] transition mb-3">
                            Ny Lestari Hadir Meramaikan Festival Kuliner Nusantara 2026
                        </h2>
                        <p class="text-gray-600 text-sm line-clamp-3 mb-4">
                            Antusiasme para pencinta kuliner sangat luar biasa saat mengunjungi stan Sambal Pecel Ny Lestari dalam ajang Pameran Warisan Kuliner Nusantara yang diselenggarakan pekan lalu...
                        </p>
                        <span class="mt-auto text-[#C0392B] font-medium text-sm flex items-center gap-1 group-hover:underline">
                            Baca Selengkapnya <i class="fa-solid fa-arrow-right text-xs"></i>
                        </span>
                    </div>
                </article>

                <!-- Berita 5 -->
                <article onclick="openModal(5)" class="bg-white rounded-2xl overflow-hidden shadow-sm border border-red-100 hover:shadow-lg transition cursor-pointer group flex flex-col">
                    <img src="https://images.unsplash.com/photo-1509358271058-acd22cc93898?auto=format&fit=crop&w=800&q=80" alt="Petani Kacang Asli" class="w-full h-56 object-cover group-hover:scale-105 transition duration-300">
                    <div class="p-6 flex flex-col flex-grow">
                        <div class="text-xs font-semibold text-[#C0392B] flex items-center gap-4 mb-3">
                            <span><i class="fa-regular fa-user me-1"></i> Admin</span>
                            <span><i class="fa-regular fa-calendar me-1"></i> 14 Januari 2026</span>
                        </div>
                        <h2 class="text-xl font-bold text-gray-900 group-hover:text-[#C0392B] transition mb-3">
                            Dukungan Ny Lestari Terhadap Petani Kacang Lokal Jawa Timur
                        </h2>
                        <p class="text-gray-600 text-sm line-clamp-3 mb-4">
                            Komitmen Ny Lestari dalam menjaga mutu tidak lepas dari kemitraan langsung bersama para petani lokal. Penggunaan bahan alami tanpa pengawet sintesis memberikan dampak positif bagi keberlanjutan...
                        </p>
                        <span class="mt-auto text-[#C0392B] font-medium text-sm flex items-center gap-1 group-hover:underline">
                            Baca Selengkapnya <i class="fa-solid fa-arrow-right text-xs"></i>
                        </span>
                    </div>
                </article>

                <!-- Berita 6 -->
                <article onclick="openModal(6)" class="bg-white rounded-2xl overflow-hidden shadow-sm border border-red-100 hover:shadow-lg transition cursor-pointer group flex flex-col">
                    <img src="https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=800&q=80" alt="Resep Kreasi Sambal Pecel" class="w-full h-56 object-cover group-hover:scale-105 transition duration-300">
                    <div class="p-6 flex flex-col flex-grow">
                        <div class="text-xs font-semibold text-[#C0392B] flex items-center gap-4 mb-3">
                            <span><i class="fa-regular fa-user me-1"></i> Admin</span>
                            <span><i class="fa-regular fa-calendar me-1"></i> 05 Desember 2025</span>
                        </div>
                        <h2 class="text-xl font-bold text-gray-900 group-hover:text-[#C0392B] transition mb-3">
                            Kreasi Unik: Bumbu Pecel Ny Lestari Sebagai Saus Batagor & Cilok
                        </h2>
                        <p class="text-gray-600 text-sm line-clamp-3 mb-4">
                            Tidak hanya lezat dinikmati bersama sayuran, bumbu pecel Ny Lestari juga sangat fleksibel diolah menjadi aneka saus cocolan makanan ringan favorit keluarga seperti batagor dan cilok...
                        </p>
                        <span class="mt-auto text-[#C0392B] font-medium text-sm flex items-center gap-1 group-hover:underline">
                            Baca Selengkapnya <i class="fa-solid fa-arrow-right text-xs"></i>
                        </span>
                    </div>
                </article>

            </div>
        </div>
    </main>

    <!-- Modal Pop-up Detail Berita -->
    <div id="newsModal" class="fixed inset-0 bg-black/60 z-[2000] hidden flex items-center justify-center p-4 backdrop-blur-sm">
        <div class="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl relative">
            <!-- Close Button -->
            <button onclick="closeModal()" class="absolute top-4 right-4 bg-gray-100 hover:bg-gray-200 text-gray-700 w-10 h-10 rounded-full flex items-center justify-center z-10 transition">
                <i class="fa-solid fa-xmark text-xl"></i>
            </button>
            <!-- Modal Content (Dynamically Injected via JS) -->
            <div id="modalContent"></div>
        </div>
    </div>

    <!-- FOOTER 3 KOLOM (HIJAU NU & TEKS PUTIH) -->
    <footer>
        <div class="footer-container">
            <!-- Kolom 1: Tentang -->
            <div class="footer-col">
                <h3>NY LESTARI</h3>
                <p>Kami adalah produsen Sambal Pecel khas Kediri yang didedikasikan untuk menyajikan kelezatan bumbu pecel berkualitas tinggi, dibuat dari bahan-bahan terbaik dan resep warisan otentik Jawa Timur.</p>
            </div>

            <!-- Kolom 2: Kontak -->
            <div class="footer-col">
                <h3>KONTAK</h3>
                <div class="footer-contact-item">
                    <i class="fas fa-map-marker-alt"></i>
                    <span>Jl Sawo, Desa Pelem - Kertosono, Jawa Timur, 64314</span>
                </div>
                <div class="footer-contact-item">
                    <i class="fas fa-phone-alt"></i>
                    <span>0822 2046 8952</span>
                </div>
            </div>

            <!-- Kolom 3: Sosial Media -->
            <div class="footer-col">
                <h3>IKUTI KAMI</h3>
                <div class="footer-socials">
                    <a href="https://www.instagram.com/nylestari_com/" target="_blank" aria-label="Instagram"><i class="fab fa-instagram"></i></a>
                    <a href="#" target="_blank" aria-label="TikTok"><i class="fab fa-tiktok"></i></a>
                </div>
            </div>
        </div>

        <!-- Copyright & Privacy Policy -->
        <div class="footer-bottom">
            <p>&copy; 2026 Copyright: <strong>Nylestari.com</strong> | <a href="javascript:void(0)" onclick="openPrivacyModal()" class="privacy-link">Kebijakan Privasi</a></p>
        </div>
    </footer>

    <!-- STRUKTUR MODAL POP-UP KEBIJAKAN PRIVASI -->
    <div id="privacyModal" class="privacy-modal">
      <div class="privacy-modal-content">
        <span class="privacy-modal-close" onclick="closePrivacyModal()">&times;</span>
        
        <div class="privacy-body">
          <h1>KEBIJAKAN PRIVASI</h1>
          <p><strong>Terakhir diperbarui:</strong> 26 September 2026</p>
          
          <p>Selamat datang di Nylestari.com, website yang menyediakan informasi dan layanan terkait Sambel Pecel Nylestari, produk makanan, informasi produk, serta informasi lain yang berkaitan dengan usaha kami.</p>
          
          <p>Kami menghargai privasi setiap pengunjung website. Kebijakan Privasi ini menjelaskan bagaimana kami mengumpulkan, menggunakan, menyimpan, dan melindungi informasi yang diperoleh melalui website <a href="https://nylestari.com/" target="_blank">https://nylestari.com/</a>.</p>
          
          <p>Dengan mengakses dan menggunakan website ini, Anda dianggap telah membaca dan memahami Kebijakan Privasi ini.</p>

          <h2>1. Informasi yang Kami Kumpulkan</h2>
          <p>Kami dapat memperoleh beberapa jenis informasi dari pengunjung website, antara lain:</p>
          
          <h3>A. Informasi yang diberikan secara langsung</h3>
          <p>Apabila Anda menghubungi kami melalui formulir kontak, WhatsApp, email, atau media komunikasi lainnya, kami dapat menerima informasi seperti:</p>
          <ul>
            <li>Nama</li>
            <li>Nomor telepon atau WhatsApp</li>
            <li>Alamat email</li>
            <li>Alamat pengiriman, apabila diperlukan untuk pemesanan</li>
            <li>Informasi mengenai produk atau pesanan</li>
            <li>Informasi lain yang secara sukarela Anda berikan kepada kami</li>
          </ul>

          <h3>B. Informasi yang dikumpulkan secara otomatis</h3>
          <p>Ketika Anda mengunjungi Nylestari.com, beberapa informasi teknis dapat dikumpulkan secara otomatis, seperti:</p>
          <ul>
            <li>Alamat IP</li>
            <li>Jenis perangkat</li>
            <li>Jenis browser</li>
            <li>Sistem operasi</li>
            <li>Halaman yang dikunjungi</li>
            <li>Waktu dan durasi kunjungan</li>
          </ul>

          <h2>2. Penggunaan Informasi</h2>
          <p>Informasi yang kami peroleh dapat digunakan untuk:</p>
          <ul>
            <li>Memberikan informasi mengenai produk Sambel Pecel Nylestari.</li>
            <li>Menanggapi pertanyaan atau permintaan dari pengunjung.</li>
            <li>Memproses komunikasi atau pemesanan apabila tersedia.</li>
            <li>Memberikan pelayanan kepada pelanggan.</li>
            <li>Meningkatkan kualitas, keamanan, dan performa website.</li>
          </ul>

          <h2>3. Hubungi Kami</h2>
          <p>Apabila Anda memiliki pertanyaan terkait Kebijakan Privasi, silakan hubungi kami di <a href="https://nylestari.com/">https://nylestari.com/</a>.</p>
        </div>
      </div>
    </div>

    <!-- STYLE MODAL PRIVACY -->
    <style>
        a.privacy-link {
            color: var(--footer-text-white) !important;
            text-decoration: underline;
            font-weight: bold;
        }

        a.privacy-link:hover {
            color: #FFD700 !important;
        }

        .privacy-modal {
            display: none;
            position: fixed;
            z-index: 2000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0,0,0,0.6);
        }

        .privacy-modal-content {
            background-color: #fefefe;
            margin: 5% auto;
            padding: 30px;
            border: 1px solid #888;
            width: 80%;
            max-width: 800px;
            border-radius: 8px;
            position: relative;
            max-height: 80vh;
            overflow-y: auto;
            color: #333;
        }

        .privacy-modal-close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
        }

        .privacy-modal-close:hover,
        .privacy-modal-close:focus {
            color: black;
            text-decoration: none;
        }

        .privacy-body h1, .privacy-body h2, .privacy-body h3 {
            margin-top: 15px;
            margin-bottom: 10px;
            color: var(--dark-color);
        }

        .privacy-body p, .privacy-body ul {
            margin-bottom: 10px;
        }

        .privacy-body ul {
            padding-left: 20px;
        }
    </style>

    <!-- JavaScript Modal Logic -->
    <script>
        // Modal Berita Logic
        const newsData = {
            1: {
                title: "Rahasia Dibalik Kelezatan Bumbu Pecel Otentik Khas Kediri",
                meta: "Admin • 20 Mei 2026",
                image: "https://images.unsplash.com/photo-1596560548464-f010549b84d7?auto=format&fit=crop&w=800&q=80",
                content: `
                    <p class="mb-4">Kuliner pecel telah menjadi salah satu identitas kekayaan rasa khas Jawa Timur. Dibalik gurih nikmatnya Sambal Pecel Ny Lestari, terdapat proses pemilihan bahan baku lokal berkualitas tinggi secara ketat.</p>
                    <p class="mb-4">Kacang tanah disangrai tanpa minyak menggunakan teknik tradisional sehingga menghasilkan cita rasa gurih alami tanpa kandungan minyak berlebih. Dipadukan dengan gula jawa murni, daun jeruk segar, kencur pilihan, dan cabai alami tanpa pewarna sintetis.</p>
                    <p>Hasilnya adalah keharmonisan rasa gurih, manis, pedas, dan aroma harum rempah yang menggugah selera keluarga Indonesia.</p>
                `
            },
            2: {
                title: "Ny Lestari Luncurkan Kemasan Praktis Kedap Udara Tahan Lama",
                meta: "Admin • 10 April 2026",
                image: "https://images.unsplash.com/photo-1613564834361-9436948817d1?auto=format&fit=crop&w=800&q=80",
                content: `
                    <p class="mb-4">Memenuhi tingginya permintaan pelanggan yang ingin membawa sambal pecel sebagai oleh-oleh ke luar kota hingga luar negeri, Ny Lestari resmi menghadirkan teknologi kemasan vakum mutakhir.</p>
                    <p class="mb-4">Kemasan baru ini dirancang kedap udara sehingga mampu menjaga kesegaran dan cita rasa bumbu tetap terjaga hingga berbulan-bulan tanpa memerlukan bahan pengawet kimia.</p>
                    <p>Kini Anda dapat menikmati kelezatan otentik pecel Kediri di mana saja dan kapan saja dengan mudah dan praktis.</p>
                `
            },
            3: {
                title: "Tips Menyajikan Pecel Segar dan Sehat untuk Sarapan Keluarga",
                meta: "Admin • 18 Maret 2026",
                image: "https://images.unsplash.com/photo-1540420773420-3366772f4999?auto=format&fit=crop&w=800&q=80",
                content: `
                    <p class="mb-4">Sarapan seimbang adalah kunci utama energi harian. Kombinasi sayuran rebus seperti kangkung, bayam, dan tauge disiram sambal pecel olahan kacang tanah sangrai menjadi menu kaya nutrisi dan serat.</p>
                    <p class="mb-4">Tips penting: rebus sayuran secukupnya agar tekstur tetap renyah dan zat gizinya tidak hilang. Larutkan Bumbu Pecel Ny Lestari dengan air hangat matang sesuai tingkat kekentalan favorit Anda.</p>
                    <p>Sajikan bersama nasi hangat, rempeyek renyah, dan tempe goreng untuk sarapan lezat nan berenergi.</p>
                `
            },
            4: {
                title: "Ny Lestari Hadir Meramaikan Festival Kuliner Nusantara 2026",
                meta: "Admin • 25 Februari 2026",
                image: "https://images.unsplash.com/photo-1555396273-367ea4eb4db5?auto=format&fit=crop&w=800&q=80",
                content: `
                    <p class="mb-4">Antusiasme para pencinta kuliner sangat luar biasa saat mengunjungi stan Sambal Pecel Ny Lestari dalam ajang Pameran Warisan Kuliner Nusantara yang diselenggarakan pekan lalu.</p>
                    <p class="mb-4">Ratusan porsi pecel racikan otentik ludes dinikmati oleh para pengunjung yang merindukan masakan khas daerah. Acara ini dikoordinasikan langsung oleh tim Ny Lestari sebagai wadah melestarikan resep tradisional Indonesia.</p>
                    <p>Terima kasih atas dukungan luar biasa dari seluruh sahabat Ny Lestari!</p>
                `
            },
            5: {
                title: "Dukungan Ny Lestari Terhadap Petani Kacang Lokal Jawa Timur",
                meta: "Admin • 14 Januari 2026",
                image: "https://images.unsplash.com/photo-1509358271058-acd22cc93898?auto=format&fit=crop&w=800&q=80",
                content: `
                    <p class="mb-4">Komitmen Ny Lestari dalam menjaga mutu tidak lepas dari kemitraan langsung bersama para petani lokal Jawa Timur. Setiap butir kacang tanah dipanen tepat waktu untuk menghasilkan kadar lemak dan rasa manis alami yang seimbang.</p>
                    <p class="mb-4">Kerja sama ini memastikan kesejahteraan para petani mitra tetap terjaga sembari menjamin ketersediaan bahan baku kualitas terbaik bagi konsumen setia kami.</p>
                    <p>Dengan membeli Sambal Pecel Ny Lestari, Anda turut mendukung perkembangan UMKM dan pertanian lokal Indonesia.</p>
                `
            },
            6: {
                title: "Kreasi Unik: Bumbu Pecel Ny Lestari Sebagai Saus Batagor & Cilok",
                meta: "Admin • 05 Desember 2025",
                image: "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=800&q=80",
                content: `
                    <p class="mb-4">Tidak hanya lezat dinikmati bersama sayuran, bumbu pecel Ny Lestari juga sangat fleksibel diolah menjadi aneka saus cocolan makanan ringan favorit keluarga seperti batagor, siomay, dan cilok.</p>
                    <p class="mb-4">Caranya cukup tambahkan sedikit kecap manis dan perasan jeruk limo pada adonan bumbu pecel yang sudah diseduh. Aroma khas daun jeruk dan kencurnya akan memberikan sensasi rasa gurih pedas yang tiada duanya.</p>
                    <p>Coba kreasikan camilan sore Anda hari ini bersama Ny Lestari!</p>
                `
            }
        };

        function openModal(id) {
            const data = newsData[id];
            if (!data) return;

            const modalContent = document.getElementById('modalContent');
            modalContent.innerHTML = `
                <img src="${data.image}" alt="${data.title}" class="w-full h-64 object-cover">
                <div class="p-6 md:p-8">
                    <span class="text-xs font-semibold text-[#C0392B] block mb-2">${data.meta}</span>
                    <h2 class="text-2xl font-bold text-gray-900 mb-4">${data.title}</h2>
                    <div class="text-gray-700 leading-relaxed text-sm md:text-base border-t border-gray-100 pt-4">
                        ${data.content}
                    </div>
                </div>
            `;
            document.getElementById('newsModal').classList.remove('hidden');
            document.body.style.overflow = 'hidden';
        }

        function closeModal() {
            document.getElementById('newsModal').classList.add('hidden');
            document.body.style.overflow = 'auto';
        }

        // Modal Privacy Policy Logic
        function openPrivacyModal() {
            document.getElementById("privacyModal").style.display = "block";
        }

        function closePrivacyModal() {
            document.getElementById("privacyModal").style.display = "none";
        }

        window.onclick = function(event) {
            const newsModal = document.getElementById('newsModal');
            const privacyModal = document.getElementById('privacyModal');
            
            if (event.target === newsModal) {
                closeModal();
            }
            if (event.target === privacyModal) {
                closePrivacyModal();
            }
        }
    </script>
</body>
</html>